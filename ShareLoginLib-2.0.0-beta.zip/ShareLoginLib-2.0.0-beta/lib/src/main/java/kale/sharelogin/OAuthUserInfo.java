package kale.sharelogin;

/**
 * @author Jack Tony
 * @date 2015/10/27
 */
public class OAuthUserInfo {

    public String nickName;
    
    public String sex;
    
    public String headImgUrl;
    
    public String userId;
    
}