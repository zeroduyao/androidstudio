package com.liulishuo.engzo.todo;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;

/**
 * @author Kale
 * @date 2016/10/6
 */

public class DemoTest {

    @Test
    public void test() {
        assertThat(null, nullValue());
    }
}
