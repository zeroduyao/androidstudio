package com.liulishuo.engzo;

import com.liulishuo.demo.BuildConfig;

/**
 * @author Kale
 * @date 2016/10/6
 */

public class Constant {

    public static final String APP_PACKAGE_NAME = BuildConfig.APPLICATION_ID;

    public static final int MAX_TIMEOUT = 5 * 1000;
    
}